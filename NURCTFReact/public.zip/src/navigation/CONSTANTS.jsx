export const HOME_URL = "/";
export const PERFIL_URL = "/perfil";
export const ABOUT_URL = "/about";
export const LOGIN_URL = "/login";
export const REGISTER_URL = "/register";
export const DESAFIO_EDIT_URL = "/desafio/editar/";
export const DESAFIO_CREATE_URL = "/desafio/create";
export const TIPO_EDIT_URL = "/tipo/editar/";
export const TIPO_CREATE_URL = "/tipo/create";
export const PISTA_EDIT_URL = "/pista/editar/";
export const PISTA_CREATE_URL = "/pista/create";
export const DESAFIO_DETAIL_URL = "/desafio/detalle/";
export const BUSCADOR_URL = "/buscador";

export const MARCADOR_URL = "/marcador";
export const DESAFIOS_URL = "/desafios";